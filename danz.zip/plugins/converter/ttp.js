exports.run = {
   usage: ['ttp'],
   hidden: ['ttpc'],
   use: 'text',
   category: 'converter',
   async: async (m, {
      client,
      text,
      args,
      isPrefix,
      command,
      canvas
   }) => {
      try {
                    if (args.length == 0) return client.reply(
                        `Text to picture. Contoh:\n` +
                        `ttp Halo sayang\n` +
                        `ttpc red Halo (warna merah)\n` +
                        `ttpc red+blue Halo (warna merah stroke biru)\n` +
                        `ttpc red-blue Halo (warna gradasi merah-biru)\n` +
                        `ttpc red-blue+white Halo (warna gradasi merah-biru stroke putih)\n`
                    )
                    let ttpBuff
                    if (command == `ttpc`) {
                        let col1 = args[0].split(`-`)[0].split(`+`)[0]
                        let col2 = args[0].split(`+`)[0].split(`-`)[1]
                        let strk = args[0].split(`+`)[1]
                        let txt = m.quoted ? m.msg : args[1]
                        ttpBuff = await canvas.ttp(txt, col1, col2, strk)
                    } else {
                        let txt = m.quoted ? m.msg : text
                        ttpBuff = await canvas.ttp(txt)
                    }
                  await client.sendSticker(m.chat, ttpBuff, m, {
                     packname: exif.sk_pack,
                     author: exif.sk_author
                  })
      } catch (e) {
         console.log(e)
         return client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false
}
