const { Configuration, OpenAIApi } = require('openai')
const configuration = new Configuration({
  apiKey: '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'
});
const openai = new OpenAIApi(configuration);
exports.run = {
   usage: ['ai'],
   hidden: ['nolep'],
   category: 'special',
   async: async (m, {
      client,
      body,
      text,
      chats,
      setting
   }) => {
      try { 
         const completion = await openai.createCompletion({model: "text-davinci-003",prompt: text,max_tokens: 2500,temperature: 0.7,stop: [" Human:", " AI:"]});
         client.reply(m.chat, completion.data.choices[0].text, m)
      } catch (e) {
         console.log(e)
      }
   },
   error: false,
   private: false,
   cache: true,
   location: __filename
}