exports.run = {
   usage: ['attp', 'ttp'],
   use: 'text',
   category: 'convert & sticker',
   async: async (m, {
      client,
      text,
      isPrefix,
      command
   }) => {
      try {      	
         let exif = global.db.setting
         if (!text) return client.reply(m.chat, Func2.example(isPrefix, command, 'halo nolep'), m)       
         let um = `https://xteam.xyz/${command}?file&text=${text}`
            await client.sendSticker(m.chat, um, m, {
               packname: exif.sk_pack,
               author: exif.sk_author
            })
          } catch {
          try {
         let anu = `https://restapi.frteam.xyz/${command}?text=${text}&apikey=Nando`
         await client.sendSticker(m.chat, anu, m, {
               packname: exif.sk_pack,
               author: exif.sk_author
            })     
      } catch (e) {
         return client.reply(m.chat, global.status.error, m)
      }
     }
   },
   error: false,
   limit: true
}