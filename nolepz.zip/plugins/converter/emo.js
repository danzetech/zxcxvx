const { EmojiAPI } = require("emoji-api")
const emoji = new EmojiAPI()
exports.run = {
   usage: ['emo'],
   hidden: ['getstik'],
   async: async (m, {
      client,
      args,
      isPrefix,
      command
   }) => {
      try {
      	if (command == 'emo') {
         if (!args || !args[0]) return client.reply(m.chat, Func.example(isPrefix, command, '🍟'), m)   
         let json = await emoji.get(args[0])
         let rows = []
            json.images.map(async (v, i) => {
               rows.push({
                  title: `EMOJI ${v.vendor.toUpperCase()}`,
                  rowId: `${isPrefix}getstik ${v.url}`,
                  description: ``
               })
            })
            client.sendList(m.chat, '', `Emojinya Kan Ada Beberapa Jenis Tuh, Kakak Mau Emoji Jenis Apa? Pilih Dibawah Ya Kak,\nHarap Perhatikan Cuma Bisa 1 Emoji Dan Gunakan Emoji. 🍟`, '', 'Klik disini ea!', [{
               rows
            }], m)
         } else if (command == 'getstik') {
         if (!args[0]) return
         sendStickerFromUrl(m.chat,`${args[0]}`)
         }
      } catch (e) {
         return client.reply(m.chat, '*emoticon tidak didukung*', m)
      }
   },
   error: false,
   limit: true,
   cache: true,
   location: __filename
}


const fs = require('fs')
const axios = require('axios')
const cheerio = require('cheerio')
const request = require('request')
const { exec, spawn, execSync } = require("child_process")

//sticker get Hinght
const sendStickerFromUrl = async(to, url) => {
                var names = Date.now() / 10000;
                var download = function (uri, filename, callback) {
                    request.head(uri, function (err, res, body) {
                        request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                    });
                };
                download(url, './media/image' + names + '.png', async function () {
                    console.log('selesai');
                    let filess = './media/image' + names + '.png'
                    let asw = './media/image' + names + '.webp'
                    exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
                        let media = fs.readFileSync(asw)
                        client.sendPresenceUpdate('composing', to)
                        client.sendSticker(to, media, m, { packname: global.db.setting.sk_pack, author: global.db.setting.sk_author })
                        fs.unlinkSync(filess)
                        fs.unlinkSync(asw)
                    });
                });
            }