const { Configuration, OpenAIApi } = require('openai')
const configuration = new Configuration({
  apiKey: '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'
});
const openai = new OpenAIApi(configuration);
exports.run = {
   usage: ['ai'],
   hidden: ['nolep'],
   category: 'special',
   async: async (m, {
      client,
      body,
      text,
      chats,
      setting
   }) => {
      try { 
         const completion = await openai.createCompletion({model: "text-davinci-003",prompt: text,max_tokens: 2500,temperature: 0.7,stop: [" Human:", " AI:"]});
         client.reply(m.chat, completion.data.choices[0].text, m)
      } catch (e) {
         console.log(e)
      }
   },
   error: false,
   private: false,
   cache: true,
   location: __filename
}