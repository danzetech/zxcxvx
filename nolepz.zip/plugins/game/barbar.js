const cron = require('node-cron')
exports.run = {
   usage: ['barbar', 'act'],
   category: 'fun games',
   async: async (m, {
      client,
      isPrefix,
      isOwner,
      command,
      participants
   }) => {    
   	if (!isOwner && global.db.users[m.sender].quota < 0) return client.reply(m.chat, global.status.quota, m)
      global.db.users[m.sender].quota -= 1
      let user = global.db.users[m.sender]
      client.barbar = client.barbar ? client.barbar : []
      if (user.point == 0) return client.reply(m.chat, Func2.texted('bold', `Kamu tidak punya point untuk bermain game barbar`), m)
      if (user.point < 1000) return client.reply(m.chat, Func2.texted('bold', `Untuk bermain minimal kamu harus mempunyai Point 1000`), m)
      if (command == 'barbar') return client.sendMessageModify(m.chat, help(isPrefix), m, {
               largeThumb: true,
               thumbnail: await Func.fetchBuffer('https://telegra.ph/file/a87f16430199678e6d131.jpg'),
               url: global.db.setting.link
            })      
      let data = global.db.users
      const percent = Func2.randomInt(1, 10)
      const member = participants.map(v => v.id)
      const player = member.filter(v => data[v] && data[v].point != 0 && v != m.sender)
      const select = Func2.random(player)
      const attack = Func2.random(['menusuk mata lawan menggunakan tusuk gigi sampai lawan meninggal',
         'membakar lawan sehingga menjadi orang hitam',
         'memakan lawan sampai lawan menjadi tulang berulang',
         'mengubur lawan hidup hidup seperti mayat',
         'memotong titit lawan',
         'membunuh lawan dengan bantuan kobo',
         'memindahkan dimensi lawan masuk ke dunia anime sehingga lawan menjadi gepeng',
         'menendang lawan sampai ke dunia animek'
      ])
      const denda = parseInt(((50 / 100) * data[m.sender].point).toFixed(0))
      // const keys = Func2.random([0, 1])
      // const dock = Func2.random([0, 1])
      let turned = client.barbar.find(player => player.id == m.sender)
      if (!turned) {
         client.barbar.push({
            id: m.sender,
            win: 0,
            cooldown: 0
         })
      }            
      if (client.barbar.length != 0) {
         cron.schedule('*/6 * * * * *', async () => client.barbar.map(v => v.win == 0))
      }      
      if (data[m.sender].guard >= 15) {
         if (data[m.sender].guard >= 10) {
            data[m.sender].guard = 0
            // if (turned.win > 0) turned.win -= 1
            let teks = `乂  *F I G H T*\n\n`
            teks += `Lawan Anda Adalah : @6285815975368 – Level : [ ∞ ]\n\n`
            teks += `*Draw!*, guard yang kamu miliki habis total dan menjadi orang hitam karena melawan Pencipta BOT dengan level Infinity`
            client.fakeStory(m.chat, teks, 'JUST FOR FUN')
         } else {
            const restrict = Func2.randomInt(5, 50)
            const point = parseInt(((restrict / 100) * data[m.sender].point).toFixed(0))
            data[m.sender].point -= point
            data[m.sender].guard = 0
            // if (turned.win > 0) turned.win -= 1
            let teks = `乂  *F I G H T*\n\n`
            teks += `Lawan Anda Adalah : @6281252848955 – Level : [ ∞ ]\n\n`
            teks += `*Kalah!*, lawanmu adalah Owner bot dengan level infinity, guardmu habis total & Point mu berkurang *- ${Func2.formatNumber(point)}* Point (${restrict}%)`
            client.fakeStory(m.chat, teks, 'JUST FOR FUN')
         }
      } else {
         if (Func2.level(data[select].point)[0] > Func2.level(data[m.sender].point)[0]) {
            if (data[m.sender].guard >= 10) {
               if (data[select].premium && data[m.sender].premium) {
                  let teks = `乂  *F I G H T*\n\n`
                  teks += `Lawan Anda Adalah : @${select.replace(/@.+/g, '')} – Level : ${Func2.level(data[select].point)[0]}\n\n`
                  teks += `*Draw!*, kamu dan lawanmu sama sama kaum elit global.`
                  client.fakeStory(m.chat, teks, 'JUST FOR FUN')
               } else if (data[select].premium) {
                  const point = parseInt(((percent / 100) * data[m.sender].point).toFixed(0))
                  data[m.sender].point -= point
                  data[select].point += point
                  // if (turned.win > 0) turned.win -= 1
                  let teks = `乂  *F I G H T*\n\n`
                  teks += `Lawan Anda Adalah : @${select.replace(/@.+/g, '')} – Level : [ ${Func2.level(data[select].point)[0]} ]\n\n`
                  teks += `*Kalah!*, lawanmu adalah bagian dari elit global, guard yang kamu miliki tidak berguna Point mu berkurang sebanyak *- ${Func2.formatNumber(point)}* Point (${percent}%)`
                  client.fakeStory(m.chat, teks, 'JUST FOR FUN')
               } else {
                  data[m.sender].guard -= 10
                  let teks = `乂  *F I G H T*\n\n`
                  teks += `Lawan Anda Adalah : @${select.replace(/@.+/g, '')} – Level : [ ${Func2.level(data[select].point)[0]} ]\n\n`
                  teks += `*Draw!*, levelmu lebih rendah dari level lawan & karena kamu mempunyai guard Point mu aman.`
                  client.fakeStory(m.chat, teks, 'JUST FOR FUN')
               }
            } else {
               if (data[select].premium && data[m.sender].premium) {
                  let teks = `乂  *F I G H T*\n\n`
                  teks += `Lawan Anda Adalah : @${select.replace(/@.+/g, '')} – Level : [ ${Func2.level(data[select].point)[0]} ]\n\n`
                  teks += `*Draw!*, kamu dan lawanmu sama sama kaum elit global.`
                  client.fakeStory(m.chat, teks, 'JUST FOR FUN')
               } else if (data[select].premium) {
                  const point = parseInt(((percent / 100) * data[m.sender].point).toFixed(0))
                  data[m.sender].point -= point
                  data[select].point += point
                  // if (turned.win > 0) turned.win -= 1
                  let teks = `乂  *F I G H T*\n\n`
                  teks += `Lawan Anda Adalah : @${select.replace(/@.+/g, '')} – Level : [ ${Func2.level(data[select].point)[0]} ]\n\n`
                  teks += `*Kalah!*, lawanmu adalah bagian dari elit global, Point mu berkurang sebanyak *- ${Func2.formatNumber(point)}* Point (${percent}%)`
                  client.fakeStory(m.chat, teks, 'JUST FOR FUN')
               } else {
                  const restrict = data[m.sender].point > 500000000 ? 50 : percent
                  const point = parseInt(((restrict / 100) * data[m.sender].point).toFixed(0))
                  data[m.sender].point -= point
                  data[select].point += point
                  // if (turned.win > 0) turned.win -= 1
                  let teks = `乂  *F I G H T*\n\n`
                  teks += `Lawan Anda Adalah : @${select.replace(/@.+/g, '')} – Level : [ ${Func2.level(data[select].point)[0]} ]\n\n`
                  teks += `*Kalah!*, levelmu lebih rendah dari level lawan, Point mu berkurang sebanyak *- ${Func2.formatNumber(point)}* Point (${percent}%)`
                  client.fakeStory(m.chat, teks, 'JUST FOR FUN')
               }
            }
         } else {
            if (data[select].guard >= 10) {
               if (data[select].premium && data[m.sender].premium) {
                  let teks = `乂  *F I G H T*\n\n`
                  teks += `Lawan Anda Adalah : @${select.replace(/@.+/g, '')} – Level : [ ${Func2.level(data[select].point)[0]} ]\n\n`
                  teks += `*Draw!*, kamu dan lawanmu sama sama kaum elit global.`
                  client.fakeStory(m.chat, teks, 'JUST FOR FUN')
               } else if (data[m.sender].premium) {
                  const point = parseInt(((percent / 100) * data[select].point).toFixed(0))
                  data[select].point -= point
                  data[m.sender].point += point
                  // turned.win += 1
                  let teks = `乂  *F I G H T*\n\n`
                  teks += `Lawan Anda Adalah : @${select.replace(/@.+/g, '')} – Level : [ ${Func2.level(data[select].point)[0]} ]\n\n`
                  teks += `*Menang!*, karena kamu bagian dari elit global, guard yang di miliki lawan tidak berguna & kamu mendapatkan *+ ${Func2.formatNumber(point)}* Point (${percent}%)`
                  client.fakeStory(m.chat, teks, 'JUST FOR FUN')
               } else {
                  data[select].guard -= 10
                  let teks = `乂  *F I G H T*\n\n`
                  teks += `Lawan Anda Adalah : @${select.replace(/@.+/g, '')} – Level : [ ${Func2.level(data[select].point)[0]} ]\n\n`
                  teks += `*Draw!*, lawan terlindungi oleh guard.`
                  client.fakeStory(m.chat, teks, 'JUST FOR FUN')
               }
            } else {
               const point = parseInt(((percent / 100) * data[select].point).toFixed(0))
               data[select].point -= point
               data[m.sender].point += point
               // turned.win += 1
               let teks = `乂  *F I G H T*\n\n`
               teks += `Lawan Anda Adalah : @${select.replace(/@.+/g, '')} – Level : [ ${Func2.level(data[select].point)[0]} ]\n\n`
               teks += `*Menang!*, kamu berhasil ${attack}, dan mendapatkan *+ ${Func2.formatNumber(point)}* Point (${percent}%)`
               client.fakeStory(m.chat, teks, 'JUST FOR FUN')
            }
         }
      }
   },
   group: true,
}

const help = prefix => {
   return `乂  *B A R B A R*

Game ini adalah game bertarung antar sesama anggota grup, berikut adalah alur permainannya :

 ​• Point setiap anggota grup punya potensi untuk bisa di ambil oleh anggota lain dengan fitur ini.
 ​• Pemain yang menang akan mendapatkan Point dari pemain yang kalah.
 ​• Point yang di tambahkan dan di kurangkan sebesar 1 - 10 persen.
 ​• Point akan terlindungi apabila pemain mempunyai *Guard*, kirim *${prefix}buyguard* untuk membeli guard.
 ​• Sekali proteksi di butuhkan 10 guard, beli guard sebanyak mungkin agar Point tetap aman.
 ​• Pemain dengan status Elit Global (Premium) bisa membypass guard lawan.
 ​• Untuk bermain silahkan kirim perintah *${prefix}act*.
 ​• 5 detik / eksekusi, jika spam akan terkena denda sebesar 50%.`
}