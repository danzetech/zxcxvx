exports.run = {
   usage: ['short'],
   use: 'link | custom',
   category: 'utilities',
   async: async (m, {
      client,
      text,
      isPrefix,
      command
   }) => {
      try {
         if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'https://google.com'), m)
         client.sendReact(m.chat, '🕒', m.key)
const caliph = require("caliph-api")
op = await caliph.tools.shortlink(text)
m.reply(`*Result* : ${op.result.url}`)      
      } catch (e) {
         console.log(e)
         client.reply(m.chat, global.status.error, m)
      }
   },
   limit: true,
   error: false
}