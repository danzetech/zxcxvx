exports.run = {
   usage: ['follower', 'like', 'view'],
   use: 'number | target',
   category: 'owner tools',
   async: async (m, {
      client,
      text,
      isPrefix,
      command
   }) => {           
     try {
let juma = text.split('|')[0] ? text.split('|')[0]: ''
let targtt = text.split('|')[1] ? text.split('|')[1]: ''
if (targtt.length < 1) return m.reply(`Jumlah dan Target harus di isi!\nExample : ${isPrefix + command} 500|lexxy456_`)
let json = await Func.fetchJson(`https://ampibismm.my.id/api/json?bot=true&api_key=hASnfGXGkVRT2NonzLePbp3wZAmzop&action=pricelist&type=${command}`)
            let rows = []
            let textplus = `${juma}|${targtt}`
            json.data.map(async (v, i) => {
               rows.push({
                  title: v.nama,
                  rowId: `${isPrefix}confirmorderkunci ${textplus}|${v.id_layanan}`,
                  description: `[ ${v.desc} | ${Func2.h2k(Func.formatNumber(v.price))} ]`
               })
            })
            client.sendList(m.chat, '', `Pilih layanan sesuai dengan yang anda inginkan, berikut adalah list yang bisa anda pilih. 🍟`, '', 'Tap!', [{
               rows
            }], m)
    } catch (e) {
    client.reply(m.chat, String(e), m)
   }
   },
   error: false,
   owner: true
}